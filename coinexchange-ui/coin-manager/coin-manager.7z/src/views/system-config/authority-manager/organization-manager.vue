<template>
  <div>
    组织机构管理
  </div>
</template>

<script>

  export default {
    data() {
      return {
      }
    },
    methods: {
    }
  }
</script>

<style scoped>

</style>


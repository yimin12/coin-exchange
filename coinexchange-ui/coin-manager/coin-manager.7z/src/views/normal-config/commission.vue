<template>
  <div>
    分佣奖励
  </div>
</template>

<script>

  export default {
    data() {
      return {
      }
    },
    methods: {
    }
  }
</script>

<style scoped>

</style>


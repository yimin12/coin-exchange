module.exports = {
  NODE_ENV: '"production"',
  // ENV_CONFIG: '"http://test.tingshuogo.com"',
  // BASE_API: '"http://test.tingshuogo.com:8091"'
}
